package edu.upc.eetac.dsa.calculadora;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class LListaOperacions extends AppCompatActivity {
    String[] oo = new String[100];
    ListView list;
    List<String> ll = new ArrayList<>();
    Button cerrarbutton;
    Button borrarhist;
    String operModificar;
    String borrOper;
    ListAdapter la;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_llista_operacions);

        //REBEM LA LLISTA DE STRINGS Y LA INTRODUIM AL ADAPTER DEL LISTVIEW PER MOSTRARLA PER PANTALLA
        Bundle in = getIntent().getExtras();
        ll.clear();
        if (list != null) {
            list.setAdapter(null);
        }


        ll = in.getStringArrayList("data");


        list = (ListView) findViewById(R.id.lista);
        la = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ll);
        list.setAdapter(la);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                // ESPECIFIQUEM QUE SI CLIQUEM A ALGUN ITEM DE LA LLISTA, S'ANIRA A LA ACTIVITAT DE TRACTAMENT DE L'OPERACIO, PASANTLI LA OPERACIO CORRESPONENT
                String choosen = ll.get(position);
                Intent in = new Intent(LListaOperacions.this, TractamentOperacio.class);
                in.putExtra("operacio", choosen);
                startActivityForResult(in, 200);

            }
        });
        // CREEM UN BOTÓ PER TANCAR L'HISTORIAL. ES PASA LA LLISTA D'OPERACIONS I SACTUALITZA A LA PANTALLA PRINCIPAL
        cerrarbutton = (Button) findViewById(R.id.cerrar);
        cerrarbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nn = getIntent();
                nn.putStringArrayListExtra("actList",(ArrayList<String>)  ll);
                setResult(RESULT_OK,nn);
                finish();
            }
        });

        //BORRAR HISTORIAL. SOBRE L'ACTIVITAT CONFIRMAR ESBORRAR
        borrarhist = (Button) findViewById(R.id.borrarhist);
        borrarhist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intt = new Intent(LListaOperacions.this, ConfirmarEsborrar.class);
                startActivityForResult(intt, 100);


            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == 100) && (resultCode == Activity.RESULT_OK)) {


            Bundle resAct = data.getExtras();
            Boolean vaciar = resAct.getBoolean("vaciar");
            if (vaciar) {
                ll.clear();
                list.setAdapter(null);
                Intent ij = getIntent();
                ij.putExtra("eliminarmemo", true);
                setResult(RESULT_OK, ij);
                finish();

            }


        }
        if ((requestCode == 200) && (resultCode == Activity.RESULT_OK)) {
            Bundle resAct = data.getExtras();
            operModificar = resAct.getString("stringOper");
            borrOper = resAct.getString("Borrar");
            int ind = 0;
            Boolean encontrado = false;
            if (borrOper != null)
            {
                for (String p : ll) {
                    if(encontrado){
                        int indd = ll.indexOf(p);
                        String[] arraCaract = p.split(" ");
                        //String idx = arraCaract[0].replace(":","");
                       // int idxi= Integer.parseInt(idx);

                        String s =String.valueOf(indd)+": "+arraCaract[1]+" "+arraCaract[2]+" "+arraCaract[3]+" "+arraCaract[4]+" "+arraCaract[5]+" ";
                        ll.set(indd,s);


                    }

                    if (p.equals(borrOper)) {
                        ind = ll.indexOf(p);
                        encontrado =true;
                    }


                }
                ll.remove(ind);

                la = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ll);
                list.setAdapter(la);


            }
            else {
                Intent kk = getIntent();

                kk.putExtra("modOper", operModificar);
                setResult(RESULT_OK, kk);
                ll.clear();
                list.setAdapter(null);
                finish();
            }


        }


    }
}