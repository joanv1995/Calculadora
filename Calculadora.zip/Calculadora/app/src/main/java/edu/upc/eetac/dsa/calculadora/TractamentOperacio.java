package edu.upc.eetac.dsa.calculadora;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TractamentOperacio extends AppCompatActivity {
    TextView viewOper;
    Button mod;
    Button borr;
    String op;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //ES REP L'STRING DE LA OPERACIÓN Y ES MOSTRA PER PANTTLA EN UN TEXTVIEW
        setContentView(R.layout.activity_tractament_operacio);
        Bundle in = getIntent().getExtras();
        op = in.getString("operacio");
        viewOper = (TextView) findViewById(R.id.voper);

        viewOper.setText(op);

        mod = (Button) findViewById(R.id.modificar);
        borr = (Button) findViewById(R.id.esborrar);

        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tt=  getIntent();
                tt.putExtra("stringOper",op);
                setResult(RESULT_OK,tt);
                finish();
            }
        });
        borr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tn = getIntent();
                String borrarOper = op;
                tn.putExtra("Borrar", borrarOper);
                setResult(RESULT_OK,tn);
                finish();

            }
        });



    }
}
