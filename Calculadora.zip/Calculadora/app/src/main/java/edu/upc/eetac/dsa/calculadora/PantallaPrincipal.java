package edu.upc.eetac.dsa.calculadora;

import android.app.Activity;
import android.content.Intent;
import android.nfc.FormatException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PantallaPrincipal extends AppCompatActivity implements  Serializable{

    //DEFINIM ELS ATRIBUTS GENERAL QUE USAREM
    String[]operaciones ={"+","-","x","/"};
    EditText numero1;
    EditText numero2;
    TextView result;
    Spinner spin;
    Button igual;
    Button borrar;
    Button verHist;
    List<String> histOper = new ArrayList<>();
    String[] arrayDatosModificar;
    String operModificar;
    Boolean modificado = false;
    int pos;
    double res;
    int cont = 0;
    String contText;
    int[][] histnums = new int[100][100];
    int[][] histposres = new int[100][100];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);

        //ENLLAÇEM LA VARIABLES CREADES AMB ELS ELEMENTS DELS LAYOUTS
        spin = (Spinner) findViewById(R.id.oper);
        numero1 = (EditText) findViewById(R.id.primerNumero);
        numero2 = (EditText) findViewById(R.id.segundoNumero);
        result = (TextView) findViewById(R.id.result);
        numero1.setText("");
        numero2.setText("");
        result.setText("");


        //INTRODUÍM L'ARRAY D'OPERACIONES AL SPINNER
        ArrayAdapter ad = new ArrayAdapter(this,android.R.layout.simple_spinner_item,operaciones);

        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(ad);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            //OBTENIM LA POSICIÓ DEL SPINNER PER SABER QUINA OPERACIÓ ES REALITZARÀ
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pos=position;


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        //ENLLAÇEM ELBOTÓ IGUAL AMB L'ELEMENT DEL LAYOUT Y SOBREESCRIBIM LA FUNCION onClick
        igual = (Button)findViewById(R.id.igual);
        igual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer num1;
                Integer num2;
                // INTRODUÏM UN TRY CATCH PER CONTROLAR LES EXCEPCIONS GENERADES
            try {
                num1 = Integer.parseInt(numero1.getText().toString());
                num2 = Integer.parseInt(numero2.getText().toString());

                if(num1==null || num2 ==null){

                    Toast.makeText(PantallaPrincipal.this, "“Cal indicar els dos valorsnumèrics",Toast.LENGTH_LONG).show();

                }
                else{
                    // SE ENTRARÁ AQUI CUAN S'ESTIGUI MODIFICANT UNA OPERACIÓ DEL HISTORIAL
                    if(modificado==true){
                        String index = arrayDatosModificar[0].replace(":","");

                        if (pos == 0) {
                            res = (double) num1 + num2;
                        } else if (pos == 1) {
                            res = (double) num1 - num2;
                        } else if (pos == 2) {
                            res = (double) num1 * num2;
                        } else if (pos == 3) {
                            res = (double) num1 / num2;
                        }
                        result.setText(String.format("%.2f", res));
                        String operChanged =index+": "+numero1.getText().toString()+" "+operaciones[pos]+" "+ numero2.getText().toString()+" = "+result.getText().toString();
                        histOper.set((Integer.parseInt(index))-1,operChanged);



                    }
                    else {
                        cont++;
                        if (pos == 0) {
                            res = (double) num1 + num2;
                        } else if (pos == 1) {
                            res = (double) num1 - num2;
                        } else if (pos == 2) {
                            res = (double) num1 * num2;
                        } else if (pos == 3) {
                            res = (double) num1 / num2;
                        }
                        result.setText(String.format("%.2f", res));
                        contText = String.valueOf(cont);
                        String opera = contText + ": " + numero1.getText().toString() + " " + operaciones[pos] + " " + numero2.getText().toString() + " = " + result.getText().toString();

                        //UN COP TENIM EL RESULTAT, CREEM UNA STRING QUE CONTINGUI ELS OPERANDS, L'PERACIÓ Y EL RESULTAT Y EL POSEM A LA LLISTA

                        histOper.add(opera);
                    }
                    modificado = false;



                }
            }
            catch (NumberFormatException ex)
            {
                    // EN CAS DE QUE NO S'INTRODUEIXI CAP VALOR, APAREIXERÁ UN TOAST

                    Toast.makeText(PantallaPrincipal.this, "Els valors han de ser valors numérics enters",Toast.LENGTH_LONG).show();
            }




            }
        });
        // BOTÓ PER ESBORRAR
        borrar=(Button) findViewById(R.id.borrar);
        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1.setText("");
                numero2.setText("");
                result.setText("0");

            }

        });
        //BOTÓ PER ANAR A VEURE L'HISTORIAL PASANT-LI LA LLISTA D'OPERACIONS REALITZADES
        verHist=(Button) findViewById(R.id.listhist);
        verHist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(PantallaPrincipal.this, LListaOperacions.class);
                inte.putStringArrayListExtra("data",(ArrayList<String>) histOper);

                startActivityForResult(inte,150);

            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if((requestCode==150)&& (resultCode == Activity.RESULT_OK)){
            Bundle resAct = data.getExtras();
            List<String> newList = resAct.getStringArrayList("actList");
            Boolean eliminar = resAct.getBoolean("eliminarmemo");
            operModificar =resAct.getString("modOper");

            if(newList!=null){
                histOper.clear();
                histOper.addAll(newList);


            }
            if(eliminar){
                histOper.clear();
                cont=0;

            }
            if(operModificar != null){
                arrayDatosModificar= operModificar.split(" ");
                numero1.setText(arrayDatosModificar[1]);
                numero2.setText(arrayDatosModificar[3]);
                result.setText(arrayDatosModificar[5]);
                for(int i =0; i<operaciones.length;i++){

                    if(arrayDatosModificar[2].equals(operaciones[i])){

                        spin.setSelection(i);

                    }

                }
                modificado = true;




            }



        }

    }
}
